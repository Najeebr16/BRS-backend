package com.lti.bus.entity;

import javax.persistence.EntityManager;
import javax.persistence.Query;

public class main {
	public static void main(String[] args) {
		test t=new test();
		t.test();
	}

}
class test {
	private  EntityManager entityManager;
	public void test() {
		Query query = entityManager.createQuery("from BusAvailibility ba where ba.source= ?1 and ba.destination= ?2");
	    query.setParameter(1, "mumbai");
		query.setParameter(2, "bangalore");
		System.out.println(query.getResultList());
	}
	
}
