package com.lti.service;
import java.util.List;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.bus.dao.BusDao;
import com.lti.bus.entity.BusAvailibility;
import com.lti.bus.entity.BusRegistration;
import com.lti.bus.entity.Login;

@Service
public class BusService {

	@Autowired
	private BusDao busDao;

	@Transactional
	public void add(BusRegistration busres) {
		busDao.add(busres);
	}
	public BusRegistration fetch(int id) {
		return busDao.fetchCustomer(id);
	}
	public List<BusAvailibility> fetchRoutes(String src,String dst) {
		return busDao.fetchRoute(src, dst);
	}
	public boolean verify(Login busres) {
		String email=busres.getUserName();
		String password=busres.getPassWord();
		boolean flag=false;
		List<BusRegistration> busresList=busDao.fetchAll();
		
		for(BusRegistration busres1:busresList) {
			if(email.equals(busres1.getEmail()) && password.equals(busres1.getPassword())) {
					 flag=true;
					 return flag;
				}
			}
		return false;
		}

}
